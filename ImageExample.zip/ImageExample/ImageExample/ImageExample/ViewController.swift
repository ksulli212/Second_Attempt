//
//  ViewController.swift
//  ImageExample
//
//  Created by user152256 on 3/27/19.
//  Copyright © 2019 Sullivan, Katherine. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

